# Install Apache.
# This is an excirpt from 'Ansible for Devops' by Jeff Geerlings
yum install --quiet -y httpd httpd-devel
# Copy configuration files.
cp httpd.conf /etc/httpd/conf/httpd.conf
# Start Apache and configure it to run at boot.
service httpd start
chkconfig httpd on
